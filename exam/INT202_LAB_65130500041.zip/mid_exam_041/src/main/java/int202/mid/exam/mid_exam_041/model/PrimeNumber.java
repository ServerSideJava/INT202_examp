package int202.mid.exam.mid_exam_041.model;


import lombok.Getter;
import lombok.Setter;
// 65130500041
@Getter
@Setter
public class PrimeNumber {
    private int number;


}
