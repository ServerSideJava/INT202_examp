package sit.int202.classicmodels.entities;

public class Environment {
    public static final String PU_NAME = "classic-models";
}
